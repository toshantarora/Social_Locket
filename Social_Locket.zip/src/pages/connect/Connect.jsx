const Connect = () => {
  return <div>Connect</div>;
};

export default Connect;
