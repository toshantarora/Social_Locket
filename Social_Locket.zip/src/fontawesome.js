import { library } from '@fortawesome/fontawesome-svg-core';
import { faBell, faUser } from '@fortawesome/free-solid-svg-icons';

library.add(faBell, faUser);
// dom.watch();
