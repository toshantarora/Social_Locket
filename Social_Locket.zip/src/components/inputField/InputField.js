const InputField = () => {
  return <div>InputField</div>;
};

export default InputField;
